package com.example.truckerapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.truckerapp.model.TruckerappBDController;
import com.example.truckerapp.model.Usuario;

public class CadastroActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        Button btnCadastrar = (Button)findViewById(R.id.btnCadastrar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TruckerappBDController crud = new TruckerappBDController(getBaseContext());
                EditText usuario = (EditText)findViewById(R.id.edtTextUsuario);
                EditText senha = (EditText)findViewById(R.id.edtTextPassword);
                EditText nome = (EditText)findViewById(R.id.edtTextNome);
                EditText idade = (EditText)findViewById(R.id.edtTextIdade);
                EditText marcaCaminhao = (EditText)findViewById(R.id.edtTextMarcaCaminhao);
                EditText modeloCaminhao = (EditText)findViewById(R.id.edtTextModeloCaminhao);
                EditText placaCaminhao = (EditText)findViewById(R.id.edtTextPlacaCaminhao);
                Usuario user = new Usuario();
                String resultado;

                user.setUsuario(usuario.getText().toString());
                user.setPassword(senha.getText().toString());
                user.setNome(nome.getText().toString());
                user.setId(Long.parseLong(idade.getText().toString()));
                user.setMarcaCaminhao(marcaCaminhao.getText().toString());
                user.setModeloCaminhao(modeloCaminhao.getText().toString());
                user.setPlacaCaminhao(placaCaminhao.getText().toString());

                resultado = crud.cadastrarUsuario(user);

                Toast.makeText(getApplicationContext(), resultado, Toast.LENGTH_LONG).show();
            }
        });
    }
}
