package com.example.truckerapp.model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class TruckerappBDCreate extends SQLiteOpenHelper {
    private static final String TRUCKERAPPDB = "truckerapp.db";
    private static final int VERSAO = 1;

    public TruckerappBDCreate(@Nullable Context context) {
        super(context, TRUCKERAPPDB, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE usuarios (id integer primary key autoincrement," +
                     "usuario text, " +
                     "senha text, " +
                     "nome text, " +
                     "idade integer, " +
                     "marca_caminhao text, " +
                     "modelo_caminhao text, " +
                     "placa_caminhao text) ";

        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        String sql = "DROP TABLE IF EXISTS usuarios";
        db.execSQL(sql);
        onCreate(db);
    }
}
