package com.example.truckerapp.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class TruckerappBDController {

    private SQLiteDatabase db;
    private TruckerappBDCreate banco;

    public TruckerappBDController (Context context) {
        banco = new TruckerappBDCreate(context);
    }

    public String cadastrarUsuario(Usuario usuario) {
        ContentValues valores;
        long resultado;

        db = banco.getWritableDatabase();
        valores = new ContentValues();
        valores.put("usuario", usuario.getUsuario());
        valores.put("senha", usuario.getPassword());
        valores.put("nome", usuario.getNome());
        valores.put("idade", usuario.getIdade());
        valores.put("marca_caminhao", usuario.getMarcaCaminhao());
        valores.put("modelo_caminhao", usuario.getModeloCaminhao());
        valores.put("placa_caminhao", usuario.getPlacaCaminhao());

        resultado = db.insert("usuarios", null, valores);
        db.close();

        if(resultado == 1) {
            return "Erro ao cadastrar usuário";
        } else {
            return "Usuário cadastrado com sucesso";
        }
    }
}
